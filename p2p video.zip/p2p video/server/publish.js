Meteor.publish('roomInformation',function(roomName){
	var room=Rooms.findOne({name: roomName});
	var subset= {
		roomType:1,
		name:1,
		passwordProtected:1,
		booked:1
	};
	if(room && !room.passwordProtected)
		subset.session=1;
	//Meteor._sleepForMs(5000);
	return Rooms.find({name: roomName},{fields: subset});
});

Meteor.publish('helpRoom',function(host){
	return Rooms.find({host: host});
});
Meteor.publish('broadcastRoom',function(name){
	return Rooms.find({host: name});
});
Meteor.publish('broadcastList',function(){
	return Rooms.find({type: 'broadcast'});
});
/******Debug******/


Meteor.publish('codepush',function(){
	return TestCode.find();
});