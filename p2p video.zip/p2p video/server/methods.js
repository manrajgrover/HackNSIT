Meteor.methods({
	'joinHelpRoom':function(host,user){
		console.log(host,user);
		var room=Rooms.findOne({host: host});
		var userId=user._id = user.userId || Random.id();

		var roomId;
		

		if(!room){

			if(!user.support){
				roomId=Rooms.insert({
					host: host,
					users: [user]
				});
			}else{
				roomId=Rooms.insert({
					host: host,
					users: []
				});
			}			
			return {
				userId: userId,
				roomId: roomId
			};
		}else{

			if(!user.support){
				room.users.push(user);
				Rooms.update(room._id,{$set: room});
			}

			return {
				userId: userId,
				roomId: room._id
			};
		}
	},
	joinBroadcastRoom:function(broadcastName,admin,name){
		var room=Rooms.findOne({'host':broadcastName});
		if(!admin){			
			if(!room)
				return;

			return {
				roomId: room._id
			};
		}else{
			if(room)
				return {
					roomId: room._id
				};

			var id=Rooms.insert({
				type: 'broadcast',
				host: broadcastName,
				name: name
			});

			return {
				roomId: id
			};
		}
	},
	'removeBroadcast': function(roomId){
		Rooms.remove({_id: roomId});
	}
});
