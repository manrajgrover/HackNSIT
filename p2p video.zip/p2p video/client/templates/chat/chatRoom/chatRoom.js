var windowIntervalId;

Template.chatRoom.onCreated(function(){
	App.reset();

	var furniture= new ReactiveDict(); //set deafults here
	furniture.set('sidebarOpen',false);

	this.furniture=furniture;

	this.furniture.setDefault('sidebarTab','information');

	Session.set('videoOn',true);
	Session.set('micOn',true);

});

Template.chatRoom.onRendered(function(){

	var speechTracker=App.streamEvents.speechTracker;
	var self=this;
	var room= Rooms.findOne();
	App.connection= new RTCMultiConnection(Session.get('user:'+room.host));

	App.connection.onstream = function(event) {
		console.log(event);
		console.log('********************************');
		createStreamElement(event);


		if(!iOS()){
			var speechEvent={
				userid: event.userid,
				streamid: event.streamid,
				hark: hark(event.stream)
			};

			speechEvent.hark.on('speaking',function(){
				$('#'+event.streamid).parent().addClass('speaking');
			});

			speechEvent.hark.on('stopped_speaking',function(){
				$('#'+event.streamid).parent().removeClass('speaking');
			});

			speechTracker.push(speechEvent);
		}
		
		App.streams.insert(event);// stream info only. other data is stripped off
		console.log(event);	  
	};

	App.connection.onstreamended = function(event) {
		//console.log(event);
		console.warn('ended');
		App.streams.remove({streamid: event.streamid});

    var stream= $('#'+event.streamid);

    speechTracker=speechTracker.filter(function(speechEvent){
    	if(speechEvent.streamid===event.streamid){
    		speechEvent.hark.stop();
    		return false;
    	}else{
    		return true;
    	}
    });
		
		var wrapper=stream.parent();
		wrapper.addClass('animated zoomOut');
 

    Meteor.setTimeout(function(){
    	wrapper.remove();
    },1000);
	    
	};

	App.connection.onUserStatusChanged = function(user) {
	    //console.log(user);
	    App.users.upsert({userid: user.userid},{$set: user});
	};


	//setup local video


	if(Session.get('broadcast')){
		initConnection();
	}else{
		App.loadPrimaryStream(function(stream){
			if(!stream){
				initConnection();
				//Session.clear('readyToJoinChat');
			}
			else{
				initConnection();
			}
		});
	}




	function createStreamElement(event){
		if(event.mediaElement){
			event.mediaElement.muted=true;
			delete event.mediaElement;
		}

		var video= document.createElement('video');
		video.controls=false;
		video.autoplay=true;
		video.src=window.URL.createObjectURL(event.stream);

		if(event.type==='local'){
			video.muted=true;
		}

		video.id=event.streamid;



		appendVideoStream(video);
		//
	}

	function appendVideoStream(videoElement){
		var topSection= $('.top-section');

		var speakingIndicator=document.createElement('div');		
		var streamWrapper = document.createElement('div');
		var wrapper=$(streamWrapper).addClass('stream-wrapper animated slideInDown')
				.append(videoElement)
				.append($(speakingIndicator).addClass('speaking-indicator'))
		    .appendTo(topSection); //main div

		Meteor.setTimeout(function(){
			wrapper.removeClass('animated slideInDown');
		},3000);
	}

	function initConnection(){

		//App.connection.attachStreams.push(App.primaryStream);
		App.connection.socketOptions = {
	    'forceNew': true, // For SocketIO version >= 1.0
	    'transport': ['websocket','polling'] // fixing transport:unknown issues
		};

	
		App.connection.session = {
		    audio: true,
		    video: true
		};

		App.connection.sdpConstraints.mandatory = {
		    OfferToReceiveAudio: true,
		    OfferToReceiveVideo: true
		};
		App.connection.closeBeforeUnload=true;
		if(!Session.get('admin')&&Session.get('broadcast')){

					App.connection.mediaConstraints.audio = false;
			    App.connection.session.audio = false;
			    App.connection.mediaConstraints.video = false;
			    App.connection.session.video = false;
		}
			

			//App.connection.dontCaptureUserMedia = true;

		App.connection.dontAttachStream=false;
		App.connection.socketURL = 'https://signal.peery.me';
		App.connection.openOrJoin();
	}




	/*****DOM*****/

	this.alignSpotlightContainer=function(){

		var spotlightContents=[];

		//spotlight is the video element
		spotlightContents.push($('.spotlight'));
		spotlightContents.push($('.primary-action')); 
		//add all spotlight content to be centered here.

		var container=$('.spotlight-container').width();
		var sidebar=$('.sidebar').width();

		spotlightContents.forEach(function(content){
			if(content.length){

				var offset=0;
				if(self.furniture.get('sidebarOpen')===false)
					offset=(container-content.width())/2;
				else
					offset= ((container-sidebar) - content.width())/2 + sidebar;

				content[0].style.transform='translate3d(-'+offset +'px,0,0)';
				setVendorStyle(content[0],'Transform','translate3d(-'+offset +'px,0,0)');

			}
		});
	};

	//TODO alignspotlightContainer on exit video fullscreen



	window.onresize=self.alignSpotlightContainer;

	self.furniture.toggleControlsVisibility= function(){

	};

	var idleTimeout = 3.0; //seconds
	var idleSecondsCounter = 0;
	window.onclick = function() {
	    idleSecondsCounter = 0;
	};
	window.onmousemove = function() {
	    idleSecondsCounter = 0;
	};
	window.onkeypress = function() {
	    idleSecondsCounter = 0;
	};
	
	windowIntervalId=window.setInterval(checkIdleTime, 500);

	function checkIdleTime() {
	    idleSecondsCounter+=500;
	    var primaryAction= $('.primary-action');
	    var sidebarAnchor= $('.sidebar .anchor');
	    var sidebarOpen=self.furniture.get('sidebarOpen');


	    if (idleSecondsCounter > idleTimeout*1000) {
	    	primaryAction.removeClass('visible');

	    	if(sidebarOpen)
	    		sidebarAnchor.addClass('visible');
	    	else
	    		sidebarAnchor.removeClass('visible');
	   		
	    }else{
	    	sidebarAnchor.addClass('visible');
	    	primaryAction.addClass('visible');

	    }
	}

	/******autoruns*********/

	function delayedAlignSpotlightContainer(delay){
    Meteor.setTimeout(function(){
    	self.alignSpotlightContainer();
    },delay||2000);
	}

	this.autorun(function(){
		//stream changes
		App.streams.find().observe({
			added: function(doc){
				delayedAlignSpotlightContainer();
			},
			changed:function(newDoc,oldDoc){
				delayedAlignSpotlightContainer();
			},
			removed:function(doc){
				delayedAlignSpotlightContainer();
			}
		});

	});

	this.autorun(function(){
		App.users.find().observe({
			added: function(doc){
				//notie.alert(1,doc.userid+' is here');
			},
			changed: function(newDoc,oldDoc){
				console.log('changed');
			}

		});
	});

	var openedOnce=false;
	this.autorun(function(){
		var open=self.furniture.get('sidebarOpen');
		var tab= self.furniture.get('sidebarTab');
		if(open){
			$('.anchor').removeClass('anchor-out').addClass('anchor-in');
			$('#'+tab).addClass('active');
		}else{
			$('.anchor').removeClass('anchor-in').addClass('anchor-out');
			$('.anchor-button.active').removeClass('active');	
		}
		self.alignSpotlightContainer();

	});
});

Template.chatRoom.onDestroyed(function(){
	clearInterval(windowIntervalId);
});

Template.chatRoom.helpers({
	topVisible:function(){

		if(Session.get('broadcast')){
			if(Template.instance().furniture.get('sidebarOpen'))
				return 'visible';
			else return 'hidden'
		}else{
			return 'visible'
		}
	
	},
	spotlightStream: function(){
		if(Session.get('broadcast'))
			return App.streams.findOne();

		if(App.streams.find().count()===1)
			return App.streams.findOne();
		else{
			return App.streams.findOne({type: 'remote'}); //change to {spotlight:true} later
		}
	},
	localAttr: function(){
		if(this.type==='local')
			return 'muted';
	},
	sidebarOpen: function(){
		if(Template.instance().furniture.get('sidebarOpen'))
			return 'visible';
	},
	videoOn:function(){
		return Session.get('videoOn');
	},
	micOn: function(){
		return Session.get('micOn');
	}
});









Template.chatRoom.events({
	'click .top-section':function(event,templ){
		var furniture=templ.furniture;
		if(furniture.get('sidebarOpen'))
			furniture.set('sidebarOpen',false);
		else
			furniture.set('sidebarOpen',true);
	},

	'click .toggle-mic': function(event,templ){
		var micOn= Session.get('micOn');
		var toggle=$('.toggle-mic');

		if(micOn){
			Session.set('micOn',false);
			toggle.addClass('active');
		}else{
			Session.set('micOn',true);
			toggle.removeClass('active');
		}
	},
	'click .toggle-video': function(event,templ){

		var videoOn= Session.get('videoOn');
		var toggle=$('.toggle-video');

		if(videoOn){
			Session.set('videoOn',false);
			toggle.addClass('active');
		}else{
			Session.set('videoOn',true);
			toggle.removeClass('active');
		}
	},

	'click #messages': function(event,templ){
		setSidebarTab(event,templ,'messages');		
	},
	'click #information': function(event,templ){
		setSidebarTab(event,templ,'information');		
	},
	'click #settings': function(event,templ){
		setSidebarTab(event,templ,'settings');		
	},

	'click #close-sidebar': function(event,templ){
		if(templ.furniture.get('sidebarOpen'))
			templ.furniture.set('sidebarOpen',false);
	},
	'click .disconnect-connection':function(event,templ){
		var room=Rooms.findOne();
		App.disconnect();
		Router.go('/');
		setTimeout(function(){
			location.reload()
			if(Session.get('admin')){
				Meteor.call('removeBroadcast',room._id);
			}
		},200);

	}

});










var previousTab;
function setSidebarTab(event,templ,tab){
	templ.furniture.set('sidebarTab',tab);

	if(! templ.furniture.get('sidebarOpen')){
		templ.furniture.set('sidebarOpen',true);
	}
	else{
		if(previousTab!==tab)
			$('.anchor-button.active').removeClass('active');

		$(event.target).addClass('active');
	}


	previousTab=tab;
}




function setVendorStyle(element, property, value) {
  element.style["webkit" + property] = value;
  element.style["moz" + property] = value;
  element.style["ms" + property] = value;
  element.style["o" + property] = value;
}