var speechEvents= {};

Template.gettingReady.onCreated(function(){
	App.initialize();
});

Template.gettingReady.onRendered(function(){

 	var options={}; 
	
	var self=this;

	var videoElement = document.querySelector('video');
	var audioSelect = document.querySelector('select#audioSource');
	var videoSelect = document.querySelector('select#videoSource');
	var videoQualitySelect= document.querySelector('select#videoQuality');

	if (App.primaryStream) {
	  videoElement.src = null;
	  App.stopPrimaryStream();
	}

	function selectFirstSourceAsDefault(){
		if(App.audioSources.find().fetch().length>0)
			audioSelect.value=App.audioSources.find().fetch()[0].id;

		if(App.videoSources.find().fetch().length>0)
			videoSelect.value=App.videoSources.find().fetch()[0].id;
	}

	selectFirstSourceAsDefault();

	var flag=true;

	function callback(stream) {

		if(!stream){
			console.log('stream-fail');
			return;
		}

	  App.primaryStream = stream; 
	  videoElement.src = window.URL.createObjectURL(stream);
	  videoElement.play();

	  if(flag){
	  	//first call
	  	selectFirstSourceAsDefault();
	  	flag=false;
	  }


	  if(!iOS()){
		  speechEvents = hark(App.primaryStream);

	    speechEvents.on('speaking', function() {
	    	console.log('speaking');
	      $('.stream-wrapper').addClass('speaking');
	    });

	    speechEvents.on('stopped_speaking', function() {
	      $('.stream-wrapper').removeClass('speaking');
	      console.log('stopped');
	    });
	  }


	}



	function start() {


		if(typeof speechEvents.stop !=='undefined')
			speechEvents.stop();

	  var videoQuality= videoQualitySelect.value;
	  if(videoQuality){
	  	options.videoConstraints=videoQuality;	
	  	Session.set('videoQuality',videoQuality);
	  }

	  options.audioSourceId = audioSelect.value;
	  Session.set('audioSourceId',options.audioSourceId);

	  options.videoSourceId = videoSelect.value;
	  Session.set('videoSourceId',options.videoSourceId);
	  App.loadPrimaryStream(callback,options);
	}

	audioSelect.onchange = start;
	videoSelect.onchange = start;
	videoQualitySelect.onchange=start;

	start();
});

Template.gettingReady.helpers({
	'source': function(sourceName){
		return App[sourceName].find();
	},
	noSourcesFound: function(sourceType){
		return App[sourceType].find().fetch().length===0;
	}
});

Template.gettingReady.events({
	'click .readyButton': function(event){
		if(!App.primaryStream){
			var message='Some Problems with your device setup :('+
				'<br>Join anyway ?';
			  
			notie.confirm(message,'Yes','No',
			  function(){//yes callback
					Session.set('readyToJoinChat',(new Date()).valueOf());
					// TODO change the date value
			    
			  },
			  function(){//no 

			  });
		}else{
			Session.set('readyToJoinChat',(new Date()).valueOf());
		}
	}
});


Template.gettingReady.onDestroyed(function(){
	if(!iOS())
		speechEvents.stop();
	else
		App.stopPrimaryStream();
});