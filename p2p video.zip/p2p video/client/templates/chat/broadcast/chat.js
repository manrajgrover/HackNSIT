Template.broadcast.onRendered(function(){

});

Template.broadcast.helpers({
	view: function(){

		if(! Session.get('admin'))
			return 'chatRoom';

		var now= new moment();
		var readyToJoinChat=Session.get('readyToJoinChat');
		if(!Rooms.findOne())
			return 'loader';

		var room= Rooms.findOne();
		

		if(readyToJoinChat){
			return 'chatRoom';
		}else{
				return 'gettingReady';
		}
	}
});