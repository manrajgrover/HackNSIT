Template.chat.onRendered(function(){

});

Template.chat.helpers({
	view: function(){
		var now= new moment();
		var readyToJoinChat=Session.get('readyToJoinChat');
		if(!Rooms.findOne())
			return 'loader';

		var room= Rooms.findOne();
		var userId=Session.get('userId');
		

		if(readyToJoinChat){
			var then= new moment(readyToJoinChat);
			if(now.diff(then,'days')>1&&room.users[0]._id===userId){
				return 'gettingReady';
			}
			else{
				if(room.users[0]._id===userId || Session.get('support')){
					return 'chatRoom';
				}
				else{
					return 'waiting';
				}
			}
		}else{
			if(!userId)
				location.reload();
			if(room.users[0]._id===userId || Session.get('support')){
				return 'gettingReady';
			}
			else{
				return 'waiting';
			}
		}
	}
});