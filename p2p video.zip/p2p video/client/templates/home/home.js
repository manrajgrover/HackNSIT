Template.home.events({
	'click .test-check': function(){
		console.log(this);
	},
	'click .createRoomButton': function(){
		let host= $('paper-input.roomInput input[name="test"]').val().trim();
		Session.set('name',host);
		host=host.split('').map(function(char){ //convert space to dash
			if(char===' ')
				return '-';
			else
				return char;
		}).join('');
		host=host.toLowerCase();
		Router.go('/b/'+host+'?admin=true');
		//Router.go('/help/'+host+'?support=true');
	},
	'click .title':function(event){
		if(Session.get('admin'))
			Session.set('admin',false)
		else
			Session.set('admin',true);
	},
	'click .list-item':function(){
		Router.go('/b/'+this.host);
	}
});

Template.home.helpers({
	admin: function(){
		console.log(Session.get('admin'))
		return Session.get('admin');
	},
	broadcast: function(){
		return Rooms.find();
	},
	noBroadcasts:function(){
		return Rooms.find().count()===0;
	}
});

Template.home.onRendered(function(){
	if(notie){
		notie.hide();
	}

	$('paper-input.roomInput input[name="test"]').keyup(function(event){
	    if(event.keyCode == 13){
	        $('.createRoomButton').click();
	    }
	});


	/***********/
/*	d= document.createElement('div');
	d.innerHTML='<i class="fa fa-video-camera">';
	$(document.body).append($(d).addClass('floater-closed').addClass('floater'));
	var open =false;
	$('.floater').click(function(){
		if(open===false){
			var iframe = document.createElement('iframe');
			iframe.src = "https://dev.peery.me/";//change
			$(this).append(iframe);
			$(this).removeClass('floater-closed').addClass('floater-open');		
			
			open=true;
		}else{
			$('iframe').remove();
			$(this).removeClass('floater-open').addClass('floater-closed')
			open=false;
		}
	})*/
});