Template.layout.onRendered(function(){
	
});