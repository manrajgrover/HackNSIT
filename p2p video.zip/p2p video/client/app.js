function loadLibs(){
	loadRTCMulticonnection();
	loadHark();
}

iOS=function detectIOS(){
	if(typeof device ==='undefined')
		return false;
	else
		return device.platform==='iOS';
};

Meteor.startup(function(){
	if(Meteor.isCordova){
		document.addEventListener('deviceready', function() {
			loadLibs();
		}, false);
	}else{
		loadLibs();
	}
});

App = {
	initialize: function(){
		function setSources(source,list){

			if(typeof App[source] !=='undefined')
				App[source].remove({});
			else
				App[source]= new Mongo.Collection(null);

			list.forEach(function(element){
				App[source].insert(element);
			});
		}
		setSources('audioSources',DetectRTC.audioInputDevices);
		setSources('videoSources',DetectRTC.videoInputDevices);
	},
	audioSources: undefined, //client MONGO COLLECTION
	/*
	{
		id: sourceId,
		label: label    //same for videoSource
	}
	*/
	videoSources: undefined, // client MONGO COLLECTION
	videoConstraints:{  //presets
		tiny: {
			maxWidth: 320,
			maxHeight: 240
		},
		vga: {
			minWidth: 640,
			minHeight: 360
		},
		HD: {
			minWidth: 1280,
			minHeight: 720
		},
		fullHD: {
			minWidth: 1920,
			minHeight: 1080
		}
	},
	primaryStreamConstraints: undefined,
	primaryStream: undefined,

	stopPrimaryStream: function(){
		App.primaryStream.getTracks().forEach(function(track){
			track.stop();
		});
	},

	loadPrimaryStream: function(callback,options){
		/*
			{
				audioSourceId: 
				videoSourceId:
				videoConstraints: 'hd/fullhd/vga' or full obj
			}

		*/

		if(!options)
			options={}; 

		if(App.primaryStream)
			this.stopPrimaryStream();			

		var constraints = { //default
		  audio: {
		    optional: [
			    {
			      sourceId: options.audioSourceId || Session.get('audioSourceId')
			    },
			    {
			    	googEchoCancellation:true
			    },
			    {
			    	googNoiseSuppression: true
			    },
			    {
			    	googTypingNoiseDetection:true
			    }			    
			   ]
		  },
		  video: {
		    optional: [{
		      sourceId: options.videoSourceId || Session.get('videoSourceId')
		    }]
		  }
		};

		//override from options
		if(options.videoConstraints){
			if(typeof options.videoConstraints==='string')
				constraints.video.mandatory=App.videoConstraints[options.videoConstraints];
			else if(typeof options.videoConstraints==='object'){
				constraints.video.mandatory=options.videoConstraints;
			}
		}else{
			if(Session.get('videoQuality'))
				constraints.video.mandatory=App.videoConstraints[Session.get('videoQuality')];
		}

		function successCallback(stream) { 
			App.primaryStreamConstraints=constraints;
			App.primaryStream=stream;
		 	callback(stream); //return stream
		}

		function errorCallback(error) {
		  console.log('navigator.getUserMedia error: ', error);
		  callback(false);//fail
		}


		navigator.getUserMedia(constraints, successCallback, errorCallback);
	},
	streams: new Mongo.Collection(null),

	streamEvents: {
		speechTracker: [],
		clearSpeechTracker: function(){
			App.streamEvents.speechTracker.forEach(function(speechEvent){
				speechEvent.hark.stop();
			});
		}
	},
	users: new Mongo.Collection(null),

	disconnect: function(){
		App.connection.getAllParticipants().forEach(function(participantId) {
    	App.connection.disconnectWith(participantId);
    	console.log('disconnected');
		});
		this.connection.close();
	},
	terminateSession: function(){
		if(this.connection)
			this.disconnect();

		if(this.primaryStream)
			this.stopPrimaryStream();

		this.streams.remove({});
		this.streamEvents.clearSpeechTracker();
		this.users.remove({});
		this.connection=undefined;
	},
	reset: function(){

		App.terminateSession();
		this.primaryStreamConstraints=undefined;
	},
	connection: undefined
};



//quick look
function streams(){
	console.log(App.streams.find().fetch());
}
function users(){
	console.log(App.users.find().fetch());
}


Streams=streams;
Users=users;